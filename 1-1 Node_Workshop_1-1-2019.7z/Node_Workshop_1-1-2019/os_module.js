var os = require('os');

//os platform
console.log("Platform: " + os.platform());

//Architecture
console.log("Architecture: " + os.arch());

// Endianness
console.log('endianness : ' + os.endianness());

// OS type
console.log('type : ' + os.type());

// Total system memory
console.log('total memory : ' + os.totalmem() + " bytes.");

// Total free memory
console.log('free memory : ' + os.freemem() + " bytes.");