var fs=require('fs');

fs.readFile('input.txt',function(err,data){

    if(err){
        console.log(err);
    }
    else{
        console.log("Async data is" + data.toString());
    
    }
});

fs.writeFile('input.txt', 'The initial release supported only Linux and Mac OS X. Its development and maintenance was led by Dahl and later sponsored by Joyent.', function (err) {
    if (err) throw err;
    console.log('Saved!');
  });

fs.appendFile('input.txt', 'Node.js was originally written by Ryan Dahl in 2009', function (err) {
    if (err) throw err;
    console.log('Saved!');
  });

var data=fs.readFileSync('input.txt');
console.log('Sync data is ' + data.toString());
console.log("This is the end "); 