var express = require('express');
var router = express.Router();
const bodyparser = require('body-parser');
const Joi = require('joi');
const jwt = require('jsonwebtoken');

var con = require('../models/db-connection');
const reg = require('../models/registration');
const update = require('../models/update');
const getAll = require('../models/get-all');
var validationpage = require('../other_modules/login-joi-validation');
var loginpage = require('../models/login');
var auditlog = require('../models/audit');

router.use(bodyparser.json());

router.post('/login', function (req, res, next) {
  validationpage.validation(req.body)//sending the mail id and password for validation
  loginpage.verifyuser(req.body)//verifying user by comparing with db values
    .then(function () {

      jwt.sign(req.body, "secretkey", (err, token) =>//if user is valid token is generated
      {
        console.log(token)
        res.json(token)
      });
    })
    .catch(console.log('ERR :: is resolving the promise'))
});

router.get('/RegistrationService', verifyToken, (req, res) => {
  jwt.verify(req.token, 'secretkey', (err, authData) => {
    if (err) {
      res.sendStatus(401);
      console.log(err);
    }
    else {
      if (loginpage.roleid == 1) {
        getAll()
          .then(function (data) {
            auditlog.insert('GET','Get all Users', loginpage.userid);
            res.json(data);
          })
          .catch(console.log("Error"));
      }
      else {
        res.send("Not an admin");
      }
    }
  });
});

router.post('/RegistrationService', (req, res) => {
  const schema = Joi.object().keys({
    name: Joi.string().regex(/^[a-zA-Z\s]{3,18}$/).required(),
    mobile_number: Joi.string().regex(/^[7-9]{1}[0-9]{9}$/).required(),
    email: Joi.string().trim().email().required(),
    password: Joi.string().min(4).max(12).required(),
    role_id_fk: Joi.number().integer().min(1).max(2)
  });
  Joi.validate(req.body, schema, (err, result) => {
    if (err) {
      console.log(err);
      res.send('An error has occurred');
    }
    else {
      console.log(result);
      reg.newUser(req.body)
        .then(function () {
          auditlog.insert('POST','New Registration', loginpage.userid);
          res.send('Successfully posted data');
        })
        .catch(console.log('ERR :: is resolving the promise'))
    }
  });
});

router.put('/UpdateUserService', verifyToken, (req, res) => {
  jwt.verify(req.token, 'secretkey', (err, authData) => {
    if (err) {
      res.sendStatus(401);
      console.log(err);
    }
    else {
      const schema = Joi.object().keys({
        user_id: Joi.number().integer().required(),
        name: Joi.string().regex(/^[a-zA-Z\s]{3,18}$/).required(),
        mobile_number: Joi.string().regex(/^[7-9]{1}[0-9]{9}$/).required(),
        email: Joi.string().trim().email().required(),
        password: Joi.string().min(4).max(12).required(),
        role_id_fk: Joi.number().integer().min(1).max(2)
      });

      Joi.validate(req.body, schema, (err, result) => {
        if (err) {
          console.log(err);
          res.send('An error has occurred');
        }
        else {
          console.log(result);
          update(req.body)
            .then(function () {
              auditlog.insert('PUT','Update user details', loginpage.userid);
              res.send("Updated successfully");
            })
            .catch(console.log('ERR :: is resolving the promise'))
        }

      });
    }
  });
});

function verifyToken(req, res, next) {
  //Get Auth Header Value
  const bearerHeader = req.headers['authorization'];
  //Check bearer is undefined
  if (typeof bearerHeader !== 'undefined') {
    //Split at th space
    const bearer = bearerHeader.split(' ');

    const bearerToken = bearer[1];

    ///console.log(bearerToken);

    req.token = bearerToken;

    //console.log(req.token);
    next();

  }
  else {
    //Forbidden
    res.sendStatus(403);
  }
}

module.exports = router;
