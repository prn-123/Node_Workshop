var encrypt = require('../other_modules/encryption');
var con = require('./db-connection');


var update = async function (data) {
    await updateRegistrationTable(data);
    var login_id = await getLoginId(data);
    const key = "My Secret Key ";
    var password = encrypt(key, data.password);
    var sql = `update login set email = '${data.email}', password = '${password}'  where login_id = ${login_id}`;
    con.query(sql, (err, rows) => {
        if (err) {
        }
        else {
            console.log("Updated successfully!");
        }
    });
}

updateRegistrationTable = function (data) {
    return new Promise(function (resolve, reject) {
        const key = "My Secret Key ";
        var password = encrypt(key, data.password);
        var mobile_number = parseInt(data.mobile_number, 10);
        var sql = `update registration set name = '${data.name}', mobile_number = ${mobile_number}, email = '${data.email}', password = '${password}', role_id_fk = '${data.role_id_fk}', last_updated_time = now()  where user_id = ${data.user_id}`;
        con.query(sql, (err, rows) => {
            if (err) {
                reject(err);
            }
            else {
                resolve(rows);
            }
        });
    });
}

var getLoginId = function (data) {
    return new Promise(function (resolve, reject) {
        const key = "My Secret Key ";
        var password = encrypt(key, data.password);
        var sql = `select * from login where user_id_fk = ${data.user_id}`;
        con.query(sql, function (err, rows) {
            console.log("inside get role id");
            if (err) {
                console.log(err);
            }
            else {
                resolve(rows[0].login_id);
            }

        });

    });
}

module.exports = update;