var encrypt = require('../other_modules/encryption');
var con = require('./db-connection');


let registration = {};

registration.newUser = async function (user) {
    await insertRegistrationTable(user);
    const user_id = await getRoleId(user);
    console.log(user_id);
    const key = "My Secret Key ";
    var password = encrypt(key, user.password);
    var sql = `insert into login(email, password, user_id_fk) values('${user.email}', '${password}', ${user_id})`;
    con.query(sql, function (err, rows) {

        if (err) {
            console.log(err);
        }
        else {
            console.log(rows);
        }

    });
}

insertRegistrationTable = function (user) {
    return new Promise(function (resolve, reject) {
        const key = "My Secret Key ";
        var password = encrypt(key, user.password);
        var mobile_number = parseInt(user.mobile_number, 10);
        console.log(mobile_number);
        console.log(user.mobile_number);
        var sql = `insert into registration(name, mobile_number, email, password, role_id_fk, created_time, last_updated_time) 
            values('${user.name}', ${mobile_number}, '${user.email}', '${password}', ${user.role_id_fk}, now(), now())`;
        con.query(sql, function (err, rows) {

            if (err) {
                console.log(err);
            }
            else {
                console.log(rows);
                resolve();
            }

        });
    });
}

getRoleId = function (user) {
    return new Promise(function (resolve, reject) {
        const key = "My Secret Key ";
        var password = encrypt(key, user.password);
        var sql = `select * from registration where email ='${user.email}' and password ='${password}'`;
        con.query(sql, function (err, rows) {
            console.log("inside get role id");
            if (err) {
                console.log(err);
            }
            else {
                registration.user_id = rows[0].user_id;
                console.log("asd" + rows[0].user_id);
                resolve(rows[0].user_id);
            }

        });

    });
}



module.exports = registration;