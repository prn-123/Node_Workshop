var mysql = require('mysql');
var bodyParser=require('body-parser');
var jwt= require("jsonwebtoken");
const Joi = require('joi')
var encryptpage = require('./encrypt')
let loginuser = {}

loginuser.verifyuser = function (input)
 {
    return new Promise(function (resolve, reject) {
        var con = mysql.createConnection  //creating database connection
        ({
            host: "192.168.50.116",
            user: "root",
            password: "ccs#1234",
            database: "shopping_db"
        });
    
        con.connect(function (err) {
            if (err) throw err;
            console.log("Connected!");
        });
        var password = encryptpage.encrypt(`${input.password}`)//encrypting the password
        let query = `select * from registration where email ='${input.email}' and password ='${password}';`
        console.log(query)
        con.query(query, function (err, result, fields) {
            
            if (err) {
                console.log(err);
                console.
                log('ERR :: fetching data from database..');
                reject();
            } else {
             
                if (result.length == 1) {
                    console.log("valid user")
                    
                    resolve(result)
                    
                } else {
                    console.log("invalid user")
                    reject();
                }
            }

        });
    });
}
loginuser.changepwd = function(input,email)
{
    return new Promise(function (resolve, reject) {
        var con = mysql.createConnection({
            host: "192.168.50.116",
            user: "root",
            password: "ccs#1234",
            database: "shopping_db"
        });
        con.connect(function (err) {
            if (err) throw err;
            console.log("Connected!");
        });
        var password = encryptpage.encrypt(`${input.password}`)//encrypting password before updation
        let query = `update registration set password ='${password}' where email ='${email}';`
        console.log(query)
        con.query(query, function (err, result, fields) {
            if (err) {
                console.log(err);
                console.
                log('ERR :: fetching data from database..');
                reject();
            } else {
                
                    resolve(result)
            }
        });
    });
}



module.exports = loginuser
