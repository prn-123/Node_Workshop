  
var crypto = require('crypto')
cryptobj ={}
var key = "My Secret Key "
cryptobj.decrypt = function(data) //function for decrypting user input
{
    var decipher = crypto.createDecipher('aes-256-cbc', key);
    var decrypted = decipher.update(data, 'hex', 'utf-8');
    decrypted += decipher.final('utf-8');
   
    return decrypted;
   }
   cryptobj.encrypt =function (data) //function for encrypting user input
   {
    var cipher = crypto.createCipher('aes-256-cbc', key);
    var crypted = cipher.update(data, 'utf-8', 'hex');
    crypted += cipher.final('hex');

    return crypted;
}
   module.exports = cryptobj