var express = require('express');//requiring all modules
var router = express.Router();
var bodyParser=require('body-parser');
var jwt= require("jsonwebtoken");
const Joi = require('joi')
var validationpage = require('../model/joival')
var loginpage = require('../model/login')

router.post('/', function (req, res, next)
 {
//   const schema = Joi.object().keys({
//     email: Joi.string().trim().email().required(),
//     password: Joi.string().min(5).max(10).required()})
//   Joi.validate(req.body, schema, (err, result) => {
//     if (err) {
//        res.send(err)
        
//     } else {
//         res.send(result);

//     }

// })
validationpage.validation(req.body)//sending the mail id and password for validation
  loginpage.verifyuser(req.body)//verifying user by comparing with db values
    .then(function () {

      jwt.sign(req.body,"secretkey",(err,token)=>//if user is valid token is generated
      { console.log(token)
         res.json(token)
      });
        })
    .catch(console.log('ERR :: is resolving the promise'))
});

router.put('/forgotpassword/:email',ensureToken, function (req, res, next) {
  validationpage.validation(req.body)
  jwt.verify(req.token, 'secretkey', function(err, data)//verifying the user with the same generated token
   {
    if (err) {
      res.sendStatus(403);
    }
  else{
  loginpage.changepwd(req.body, req.params.email)
    .then(function () {
      res.send("password changed successfully")
    })
    .catch(console.log('ERR :: is resolving the promise'))
  }
});
});
function ensureToken(req, res, next) //requiring token from header
{
  const bearerHeader = req.headers["authorization"];
  if (typeof bearerHeader !== 'undefined') {
    const bearer = bearerHeader.split(" ");
    const bearerToken = bearer[1];
    req.token = bearerToken;
    next();
  } else {
    res.sendStatus(403);
  }
}
module.exports = router;