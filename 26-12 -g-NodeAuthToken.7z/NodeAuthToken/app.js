const express = require('express');
const jwt = require('jsonwebtoken');
const bodyparser = require('body-parser');

const app = express();

app.use(bodyparser.json());


app.get('/api', (req,res) => {
 res.json({
    message: 'Welcome to the API' 
  });
});

app.post('/l/p', VerifyToken, (req, res)=>{
    jwt.verify(req.token, 'secretkey', (err,authData) => {
        console.log(authData);
        if(err){
            res.sendStatus(403);
        }
        else{
            res.json({message: 'Post created', authData});
        }
    });
});
//To get token use this 
app.post('/l',(req, res) =>{
   console.log(req.body)
    var user = {
        id: req.body.id,
        username: req.body.username,
        email: req.body.email
    };
    jwt.sign({user}, 'secretkey', (err, token) =>{
        res.json({
            token
        });
    });
});

//Format of token
//Authorization : Bearer<access_token>

//Verify token
function VerifyToken(req, res, next){
    //Get Auth Header Value
    const bearerHeader = req.headers['authorization'];
    //Check bearer is undefined
    if(typeof bearerHeader !== 'undefined'){
        //Split at th space
        const bearer = bearerHeader.split(' ');

        const bearerToken = bearer[1];

        ///console.log(bearerToken);

        req.token = bearerToken;

        //console.log(req.token);
        next();

    }
    else{
        //Forbidden
        res.sendStatus(403);
    }
}

app.listen(8001, ()=> console.log('Server started on port 8001'));


// app.post('/login', (req, res) => {
//     //res.send(req.body);
//     var user = {
//         id: req.body.id,
//         name: req.body.name
//     };
//     console.log(user);
//     jwt.sign({ user }, 'secretkey', (err, token) => {
//         if (err) {
//             console.log(err);
//         }
//         else {
//             res.json({ token });
//         }
//     });
// });
// app.post('/post', verifyToken, (req,res)=>{
//     jwt.verify(req.token, 'secretkey', (err,authData) => {
//         console.log(authData);
//         if(err){
//             res.sendStatus(403);
//         }
//         else{
//             res.json({message: 'Post created', authData});
//         }
//     });
// });

// function verifyToken(req, res, next){
//     //Get Auth Header Value
//     const bearerHeader = req.headers['authorization'];
//     //Check bearer is undefined
//     if(typeof bearerHeader !== 'undefined'){
//         //Split at th space
//         const bearer = bearerHeader.split(' ');

//         const bearerToken = bearer[1];

//         ///console.log(bearerToken);

//         req.token = bearerToken;

//         //console.log(req.token);
//         next();

//     }
//     else{
//         //Forbidden
//         res.sendStatus(403);
//     }
// }
