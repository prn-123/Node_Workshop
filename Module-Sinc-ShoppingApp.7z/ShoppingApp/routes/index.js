var express = require('express');
var router = express.Router();
const Joi = require('joi');
const jwt = require('jsonwebtoken');
var ProductIns = require('../models/ProductInsert')
var ProductUpdate = require('../models/ProductUpdate')
var Productselet = require('../models/ProductSelect')

/* posting new record. */
router.post('/newProduct', verifyToken, function (req, res) {
  console.log(req.body);
  jwt.verify(req.token, 'secretkey', (err, authData) => {
    if (err) {
      res.sendStatus(403)
    }
    else {

      /* Joi validation */
      const schema = Joi.object().keys({
        ProductName: Joi.string().required(),
        Invoice: Joi.number().integer().required(),
        MRP: Joi.number().required(),
      });

      Joi.validate(req.body, schema, (err, result) => {
        if (err) {
          console.log(err);
          res.send(err.message);
        }
        else {
          console.log(result);

          ProductIns.NewRecord(req.body)
            .then(function () {
              res.send('Record inserted successfully...')
            })
            .catch(console.log('ERR :: is resolving the promise'))
        }

      });
    }
  });
});

/* updating the product record */
router.put('/updateProduct/:id', verifyToken, function (req, res) {
  console.log(req.body, req.params.id);
  jwt.verify(req.token, 'secretkey', (err, authData) => {
    if (err) {
      res.sendStatus(403)
    }
    else {


      /* Joi validation */
      const schema = Joi.object().keys({
        ProductName: Joi.string(),
        Invoice: Joi.number().integer(),
        MRP: Joi.number()
      });

      Joi.validate(req.body, schema, (err, result) => {
        if (err) {
          console.log(err);
          res.send(err.message);
        }
        else {
          console.log(result);
          ProductUpdate.UpdateRecord(req.body, req.params.id)
            .then(function () {
              res.send('Record updated successfully...')
            })
            .catch(console.log('ERR :: is resolving the promise'))
        }

      });
    }
  });
});

/*SELECT Product  */
router.get('/', verifyToken, function (req, res) {
  jwt.verify(req.token, 'secretkey', (err, authData) => {
    if (err) {
      res.sendStatus(403)
    }
    else {

      Productselet.getAll()
        .then(function (data) {
          res.send(data)
        })
        .catch(console.log('ERR :: is resolving the promise'))
    }
  });
})

/*SELECT Product  by id*/
router.get('/:id', verifyToken, function (req, res) {
  jwt.verify(req.token, 'secretkey', (err, authData) => {
    if (err) {
      res.sendStatus(403)
    }
    else {

      Productselet.getById(req.params.id)
        .then(function (data) {
          res.send(data)
        })
        .catch(console.log('ERR :: is resolving the promise'))
    }
  });
})

/*SELECT Product  */
router.get('/get/:location', verifyToken, function (req, res) {
  jwt.verify(req.token, 'secretkey', (err, authData) => {
    if (err) {
      res.sendStatus(403)
    }
    else {

      Productselet.getByLocation(req.params.location)
        .then(function (data) {
          res.send(data)
        })
        .catch(console.log('ERR :: is resolving the promise'))
    }
  });
})

function verifyToken(req, res, next) {
  // Get auth header value
  const bearerHeader = req.headers['authorization'];
  // Check if bearer is undefined
  if (typeof bearerHeader !== 'undefined') {
    // Split at the space
    const bearer = bearerHeader.split(' ');
    // Get token from array
    const bearerToken = bearer[1];
    // Set the token
    req.token = bearerToken;
    // Next middleware
    next();
  } else {
    // Forbidden
    res.sendStatus(403);
  }

}

router.post('/api/login', (req, res) => {
  //Mock user
  const user = {
    user_id: 3
  }
  jwt.sign({ user }, 'secretkey', (err, token) => {
    res.json({
      token
    });
  })
});

module.exports = router;
