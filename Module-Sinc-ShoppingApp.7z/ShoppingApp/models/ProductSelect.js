const db = require('./dbconnection');


let Productselect = {}

Productselect.getAll = function () {
    return new Promise(function (resolve, reject) {
        let query = `CALL ProductService('selectAll',0,'','',0,0);`;
        db.query(query, function (err, result, fields) {
            if (err) {
                console.log(err);
                console.log('ERR :: fetching data from database..');
                reject();
            }
            else {
                console.log(result);
                console.log(fields);
                resolve(result);
            }

        });

    });
}

Productselect.getById = function (id) {
    return new Promise(function (resolve, reject) {
        let query = `CALL ProductService('selectById',${id}, '','',0, 10);`;
        db.query(query, function (err, result, fields) {
            if (err) {
                console.log(err);
                console.log('ERR :: fetching data from database..');
                reject();
            }
            else {
                console.log(result);
                console.log(fields);
                resolve(result);
            }

        });

    });
}

Productselect.getByLocation = function (location) {
    console.log(location);
    return new Promise(function (resolve, reject) {
        let query = `CALL ProductService('selectByLoc',0,'${location}','',0,0);`;
        console.log(query);

        db.query(query, function (err, result, fields) {
            if (err) {
                console.log(err);
                console.log('ERR :: fetching data from database..');
                reject();
            }
            else {
                console.log(result);
                console.log(fields);
                resolve(result);
            }

        });
    });

}


module.exports = Productselect;