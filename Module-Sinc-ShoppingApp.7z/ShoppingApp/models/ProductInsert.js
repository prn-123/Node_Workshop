const db = require('./dbconnection');
const Joi = require('joi');

let ProductInsert = {}

ProductInsert.NewRecord = function (newProduct) {
	console.log(newProduct)
	return new Promise(function (resolve, reject) {
		let query = `CALL ProductService('insert',0,'','${newProduct.ProductName}',${newProduct.Invoice},${newProduct.MRP})`
		//`INSERT INTO Product(ProductName, CategoryId, InvoiceNo, MRP, CreatedTime, ProdUserId) VALUES('${newProduct.ProductName}',1,${newProduct.Invoice}, ${newProduct.MRP}, now(),1 );`;
		db.query(query, function (err, result, fields) {
			if (err) {
				console.log(err);
				console.
				log('ERR :: fetching data from database..');
				reject();
			}
			else {
				console.log(result);
				console.log(fields);
				resolve(result);
			}

		});

	});
}

module.exports = ProductInsert;