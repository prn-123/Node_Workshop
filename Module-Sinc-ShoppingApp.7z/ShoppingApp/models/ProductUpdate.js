const db = require('./dbconnection');

let ProductUpdate = {}

ProductUpdate.UpdateRecord = function (newProduct, id) {
	console.log(newProduct)
	return new Promise(function (resolve, reject) {
		let query =`CALL ProductService('update',${id}, '','${newProduct.ProductName}',${newProduct.Invoice},${newProduct.MRP})`;
		//`UPDATE Product SET ProductName = '${newProduct.ProductName}',  InvoiceNo= ${newProduct.Invoice}, MRP= ${newProduct.MRP}, CreatedTime= now() WHERE Product_Id= ${id};`;
		console.log(query);
		db.query(query, function (err, result, fields) {
			if (err) {
				console.log(err);
				console.log('ERR :: fetching data from database..');
				reject();
			}
			else {
				console.log(result);
				console.log(fields);
				resolve(result);
			}

		});

	});
}

module.exports = ProductUpdate;