const mysql = require('mysql');

// create the connection to database
// const connection = mysql.createConnection({
//     host: '192.168.50.116',
//     user: 'root',
//     database: 'shopping_db',
//     password: 'ccs#1234'
// });



const connection = mysql.createConnection({
    host: 'papldb.cjupr4mqlpqh.ap-south-1.rds.amazonaws.com',
    //port: 3306,
    user: 'root',
    database: 'bestprice',
    password: 'Butlers#123',
    multipleStatements: true
});


module.exports = connection;