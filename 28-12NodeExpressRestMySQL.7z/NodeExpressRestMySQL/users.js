var mysql = require('mysql');


var connection = mysql.createConnection({
	host: 'localhost',
	user: 'root',
	password: 'ccs#1234',
	port: '3306',
	database: 'contacts'
});


exports.select = function (req, res) {
	var query = connection.query("select * from contact", function (err, rows) {
		if (err) {
			console.log("Error in selected query");
		}
		else {
			res.send(rows);
		}
	});
}

//insert query function
exports.add = function (req, res) {
	var name = req.body.name;
	var location = req.body.location;

	var query = connection.query(`insert into  contact(name,location) values('${name}', '${location}')`, function (err, rows) {
		if (err) {
			console.log("Error in insert query");
		}
		else {
			res.redirect('/');
		}
	});
}


//update query function
exports.update = function (req, res) {
	//defining id as dynamic request parameter
	var id = req.params.id;

	let _query = `UPDATE contact SET name='${req.body.name}',location='${req.body.location}' where id = '${req.params.id}'`;
	connection.query(_query, (err, rows, fields) => {

		if (!err) {
			res.send(req.body);
		}
		else{
			console.log(err);
		}
	})
}

//delete query function
exports.delete = function (req, res) {
	//defining id as dynamic request parameter
	var id = req.params.id;

	var query = connection.query("delete from contact where id = ?", [id], function (err, rows) {
		if (err) {
			console.log("Error in delete query");
		}
		else {
			res.redirect('/');
		}
	});
} 