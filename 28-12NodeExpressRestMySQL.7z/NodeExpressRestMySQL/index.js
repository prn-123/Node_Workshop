var express = require('express');
var app = express();
const bodyparser = require('body-parser');

app.use(bodyparser.json());

//using router to define custom url.
var router = express.Router();

//importing  users.js.
var users = require('./users.js');

//going to use router to call select function.
router.get('/', users.select);

//going to use router to call insert function.
router.post('/add', users.add);

//going to use router to call update function.
router.put('/update/:id', users.update);

//going to use router to call update function.
router.delete('/delete/:id', users.delete);

//telling engine to use router in our app.
app.use('/', router);

/*app.get('/',function(req,res){
	res.send('Hello World!');
});
*/

app.listen('3000', function(req,res){
	console.log('Server is listening at port no. 3000');
});