const Joi = require('joi');
joiobj = {};

joiobj.validation = function (inj) {
   const schema = Joi.object().keys({
      email: Joi.string().trim().email().required(),
      password: Joi.string().min(4).max(8).required()
   });
   Joi.validate(inj, schema, (err, result) => {
      if (err) {
         console.log(err);
      } else {
         console.log("success");

      }

   })
}
module.exports = joiobj;