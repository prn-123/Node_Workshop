var con = require('./db-connection');

var getUser = function(user_id){
    return new Promise(function(resolve, reject) {
    var qry = con.query(`select name, mobile_number, email, password, role_id_fk from registration where user_id = ${user_id}`, (err, rows) => {
        if (err) {
          console.log("Error in fetching data from database");
          res.send("Error in fetching data from database");
          reject();
        }
        else {
          resolve(rows[0]);
          console.log("hiiiiiiiiiiiiiiiiiiiiii" + rows[0]|JSON) ;
        }
      });
    });
}


module.exports = getUser;