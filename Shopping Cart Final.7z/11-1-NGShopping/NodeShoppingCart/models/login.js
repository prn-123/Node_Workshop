var mysql = require('mysql');
var bodyParser = require('body-parser');
var encrypt = require('../other_modules/encryption');
var con = require('./db-connection');


let loginuser = {};

loginuser.verifyuser = function (input) {
    return new Promise(function (resolve, reject) {
        // con.connect(function (err) {
        //     if (err) throw err;
        //     console.log("Connected!");
        // });HandShake
        const key = "My Secret Key ";
        var password = encrypt(key, input.password);//encrypting the password
        let query = `select * from registration where email ='${input.email}' and password ='${password}';`
        console.log(query)
        con.query(query, function (err, result, fields) {

            if (err) {
                console.log(err);
                console.log('ERR :: fetching data from database..'); 
                reject(err);
            } else {

                if (result.length == 1) {
                    console.log("valid user")
                    console.log(result[0].role_id_fk);
                    loginuser.roleid = result[0].role_id_fk;
                    loginuser.userid=result[0].user_id;
                    resolve(result)

                } else {
                    console.log("invalid user")
                    reject();
                }
            }

        });
    });
}




module.exports = loginuser
