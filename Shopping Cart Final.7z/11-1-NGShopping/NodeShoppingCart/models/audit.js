const db = require('./db-connection');

let auditlog = {};

auditlog.insert = function(methodname,servicename,userid) {
 let query = `INSERT INTO audit_log (method_name, service_name, user_id_fk, created_time) VALUES('${methodname}','${servicename}',${userid},now())`;
 console.log(query);
 db.query(query, (err, result) => {
 if (err) {
 console.log(err);
 }
 else {
 console.log("log created");
 }
 })
}

module.exports = auditlog;
