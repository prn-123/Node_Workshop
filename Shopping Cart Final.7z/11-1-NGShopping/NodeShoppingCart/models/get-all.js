var con = require('./db-connection');

var getAll = function(){
    return new Promise(function(resolve, reject) {
    var qry = con.query("select * from registration ", (err, rows) => {
        if (err) {
          console.log("Error in fetching data from database");
          res.send("Error in fetching data from database");
          reject();
        }
        else {
          resolve(rows);
        }
      });
    });
}

module.exports = getAll;