var encrypt = require('../other_modules/encryption');
var con = require('./db-connection');


var update = async function (data, user_id) {
    console.log("login_id inside update");
    await updateRegistrationTable(data, user_id);
    var login_id = await getLoginId(user_id);
    const key = "My Secret Key ";
    var password = encrypt(key, data.password);
    var sql = `update login set email = '${data.email}', password = '${password}'  where login_id = ${login_id}`;
    con.query(sql, (err, rows) => {
        if (err) {
        }
        else {
            console.log("Updated successfully!");
        }
    });
}

updateRegistrationTable = function (data, user_id) {
    return new Promise(function (resolve, reject) {
        const key = "My Secret Key ";
        var password = encrypt(key, data.password);
        var mobile_number = parseInt(data.mobile_number, 10);
        console.log("login_id inside updateRegTable");
        var sql = `update registration set name = '${data.name}', mobile_number = ${mobile_number}, email = '${data.email}', password = '${password}', role_id_fk = '${data.role_id_fk}', last_updated_time = now()  where user_id = ${user_id}`;
        con.query(sql, (err, rows) => {
            if (err) {
                reject(err);
            }
            else {
                resolve(rows);
            }
        });
    });
}

var getLoginId = function (user_id) {
    return new Promise(function (resolve, reject) {
        // const key = "My Secret Key ";
        // var password = encrypt(key, data.password);
        console.log("login_id inside getLoginId");
        var sql = `select * from login where user_id_fk = ${user_id}`;
        con.query(sql, function (err, rows) {
            console.log("inside get role id");
            if (err) {
                console.log(err);
            }
            else {
                resolve(rows[0].login_id);
                console.log('Pournami R Nair' + rows[0].login_id);
            }

        });

    });
}

module.exports = update;