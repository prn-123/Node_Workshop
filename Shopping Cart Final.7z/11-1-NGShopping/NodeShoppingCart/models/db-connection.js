var mysql = require('mysql');

// var connection = mysql.createConnection({
//     host: 'papldb.cjupr4mqlpqh.ap-south-1.rds.amazonaws.com',
//     port: 3306,
//     user: 'root',
//     password: 'Butlers#123',
//     database: 'bestprice',
//     multipleStatements: true
// });
var connection = mysql.createConnection({
    host: '192.168.50.116',
    user: 'root',
    password: 'ccs#1234',
    port: '3306',
    database: 'shopping_db',
    multipleStatements: true
});

module.exports = connection ;