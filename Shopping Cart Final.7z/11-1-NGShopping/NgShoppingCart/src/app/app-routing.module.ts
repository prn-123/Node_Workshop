import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GetAllUserComponent } from './get-all-user/get-all-user.component';
import { RegistrationComponent } from './registration/registration.component';
import { UpdationComponent } from './updation/updation.component';
import { LoginComponent } from './login/login.component';

const routes: Routes = [{path: 'getAllUser', component: GetAllUserComponent},
{ path: 'newUser', component: RegistrationComponent },
{ path: 'update/:id', component: UpdationComponent },
{ path: 'getAllUser', component: GetAllUserComponent },
{ path: 'login', component: LoginComponent},
{ path: '',   redirectTo: '/login', pathMatch: 'full' }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
