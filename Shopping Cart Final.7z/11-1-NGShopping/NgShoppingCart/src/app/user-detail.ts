export class UserDetail {
    [x: string]: any;
    user_id: number;
    name: string;
    mobile_number: string;
    email: string;
    password: string;
    role_id_fk: number;
    created_time: Date;
    last_updated_time: Date;
}
