import { Component, OnInit } from '@angular/core';
import { ShoppingService } from '../shopping.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user = {
    email: '',
    password: ''
  }

  constructor(private shoppingService: ShoppingService, private router: Router) { }

  ngOnInit() {
  }

  login() {
    try {
      console.log(this.user, "user")
      this.shoppingService.login(this.user)
        .subscribe(resp => {
          if (resp != null) {
            console.log("token is not null");
            this.shoppingService.settoken(resp)
            console.log(resp, "res");
            this.router.navigate(['getAllUser']);
            //this.router.navigateByUrl('getAllUser')
          }
        },
          error => {
            console.log(error, "error");
            alert("Invalid Username or Password !");
            this.user = {
              email: '',
              password: ''
            }
          
          })
    } catch (e) {
      console.log(e);
    }
  }

}
