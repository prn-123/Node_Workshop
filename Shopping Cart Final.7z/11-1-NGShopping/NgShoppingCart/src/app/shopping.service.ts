import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { User } from './user';
import { Registration } from './registration';
import { UserDetail } from './user-detail';

@Injectable({
  providedIn: 'root'
})
export class ShoppingService {

  constructor(private http: HttpClient) { }

  
  getAllUser(): Observable<UserDetail[]> {//Get all user details.
    var token = localStorage.getItem("access_token");//Getting token from local storage.
    const httpOptions = {
      headers: new HttpHeaders({
        'Authorization': 'Bearer ' + token,
        //'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6InBvdXJuYW1pQGNjcy5vcmcgIiwicGFzc3dvcmQiOiJwb3VybmFtaSIsImlhdCI6MTU0NzcxNzI2NX0.GOMtPXz0XJSP57AXhSOm0asamzcCVxNdwThq0JEtM9g',
      })
    };
    return this.http.get<UserDetail[]>('http://localhost:3000/getAllUser', httpOptions);
  }


  getUser(id: number): Observable<User> {//Get a user.
    var token = localStorage.getItem("access_token");//Getting token from local storage.
    const httpOptions = {
      headers: new HttpHeaders({
        'Authorization': 'Bearer ' + token,
        //'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6InBvdXJuYW1pQGNjcy5vcmcgIiwicGFzc3dvcmQiOiJwb3VybmFtaSIsImlhdCI6MTU0NzcxNzI2NX0.GOMtPXz0XJSP57AXhSOm0asamzcCVxNdwThq0JEtM9g',
      })
    };
    return this.http.get<User>('http://localhost:3000/getUser/' + id, httpOptions);
  }

  saveUserData(registration: Registration): Observable<Registration> {
    const header = new HttpHeaders({ 'content-Type': 'application/Json' });
    return this.http.post<Registration>('http://localhost:3000/RegistrationService', registration, { headers: header });
    //http://192.168.50.122:4000/reg/RegistrationService
    //http://localhost:4200
  }

  updateUserData(user: User, id: number): Observable<User> {
    var token = localStorage.getItem("access_token");
    const httpOptions = {
      headers: new HttpHeaders({
        'Authorization': 'Bearer ' + token,
        //'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6InBvdXJuYW1pQGNjcy5vcmcgIiwicGFzc3dvcmQiOiJwb3VybmFtaSIsImlhdCI6MTU0NzcxNzI2NX0.GOMtPXz0XJSP57AXhSOm0asamzcCVxNdwThq0JEtM9g',
      })
    };
    console.log("Inside shopping service" + user.user_id);
    const header = new HttpHeaders({ 'content-Type': 'application/Json' });
    return this.http.put<User>('http://localhost:3000/UpdateUserService/' + id, user, httpOptions);
  }

  login(data) {
    console.log(data);
    return this.http.post('http://localhost:3000/login', data);
  }

  settoken(data) {
    localStorage.setItem('access_token', data);
    //console.log(this.token, "token");
  }

}
