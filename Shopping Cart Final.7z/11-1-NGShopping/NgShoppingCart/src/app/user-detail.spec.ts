import { UserDetail } from './user-detail';

describe('UserDetail', () => {
  it('should create an instance', () => {
    expect(new UserDetail()).toBeTruthy();
  });
});
