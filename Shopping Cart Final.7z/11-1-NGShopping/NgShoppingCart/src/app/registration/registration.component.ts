import { Component, OnInit } from '@angular/core';
import { Registration } from '../registration';
import { ShoppingService } from '../shopping.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {


  constructor(private shoppingService: ShoppingService, private router: Router) { }
  user: Registration;

  ngOnInit() {
    this.newUser();
  }

  newUser(): void{
  this.user = {
    name: '',
    mobile_number: null,
    email: '',
    password: '',
    role_id_fk: null
  };
}


saveData(): void{
  this.shoppingService.saveUserData(this.user).subscribe(user => this.user.push(user));
  alert("Data saved Successfully!");
  this.router.navigate(['login']);
}
}
