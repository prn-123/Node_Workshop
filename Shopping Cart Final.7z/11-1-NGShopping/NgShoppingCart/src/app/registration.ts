export class Registration {
  [x: string]: any;
    name: string;
    mobile_number: string;
    email: string;
    password: string;
    role_id_fk: number;
}
