import { Component, OnInit } from '@angular/core';
import { ShoppingService } from '../shopping.service';
import { HttpClient } from '@angular/common/http';
import { UserDetail } from '../user-detail';
import { Router } from '@angular/router';

@Component({
  selector: 'app-get-all-user',
  templateUrl: './get-all-user.component.html',
  styleUrls: ['./get-all-user.component.css']
})
export class GetAllUserComponent implements OnInit {

  users: UserDetail[];
  constructor(private shoppingService: ShoppingService, private router: Router) { }

  ngOnInit() {
    this.getAll();
  }

  
  getAll(){
    //const header = new HttpHeaders({'content-Type': 'application/Json'});
    this.shoppingService.getAllUser().subscribe(users =>this.users = users); 
    if(localStorage.getItem('access_token') == ' '){
    this.router.navigate(['login']);
    }
    //this.http.get<User[]>('http://localhost:3000/RegistrationService').subscribe(users =>this.users = users);
  }

  g_signOut(){
    localStorage.setItem('access_token', ' ');
    console.log("inside signOut");
  }

}
