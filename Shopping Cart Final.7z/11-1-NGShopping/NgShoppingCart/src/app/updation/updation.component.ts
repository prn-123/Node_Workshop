import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ShoppingService } from '../shopping.service';
import { User } from '../user';
import { ActivatedRoute, Router } from '@angular/router';
import { userInfo } from 'os';

@Component({
  selector: 'app-updation',
  templateUrl: './updation.component.html',
  styleUrls: ['./updation.component.css']
})
export class UpdationComponent implements OnInit {

  user: any;
  constructor(private shoppingService: ShoppingService, private http: HttpClient, private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    if(localStorage.getItem('access_token') == ' '){
      this.router.navigate(['login']);
      }
    this.getUser();
  }

  getUser(){
    const id = +this.route.snapshot.paramMap.get('id');
    //const header = new HttpHeaders({'content-Type': 'application/Json'});
    this.shoppingService.getUser(id).subscribe(user =>this.user = user);
    console.log(this.user);
   //this.http.get<User[]>('http://localhost:3000/RegistrationService').subscribe(users =>this.users = users);
  }

  updateData(): void{
    console.log(this.user.mobile_number);
    this.user.mobile_number = (this.user.mobile_number).toString();
    console.log(this.user.mobile_number);
    const id = +this.route.snapshot.paramMap.get('id');
    this.shoppingService.updateUserData(this.user, id).subscribe(user => this.user.push(user));
    alert("Data updated Successfully");
    this.router.navigate(['getAllUser']);
  
  }

  signOut(){
    localStorage.setItem('access_token', ' ');
    console.log("inside signOut");
  }
   
}
